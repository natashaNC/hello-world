from django.apps import AppConfig


class QueriesAppConfig(AppConfig):
    name = 'queries_app'
