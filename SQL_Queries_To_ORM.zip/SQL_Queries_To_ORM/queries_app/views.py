from django.shortcuts import render, redirect, HttpResponse

def index(request):

    return HttpResponse ("index.html")
# Create your views here.
