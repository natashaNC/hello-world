from django.shortcuts import render, HttpResponse, redirect
from .models import Book, Author

def AddABook(request):
    context = {
        'all_books': Book.objects.all()
    }
    return render(request, "01_AddABook.html", context)

def InputBook(request):
    print(request.POST)
    newBook = Book.objects.create(title=request.POST['title_add'], desc=request.POST['desc_add'])
    return redirect("/")

def BookInfo(request, book_id):    
    varbookID = book_id
    request_book = Book.objects.get(id=book_id)
    context = {
        'requested_book': Book.objects.get(id=book_id),
        'book_authors': request_book.authors.all(),
        'other_authors': Author.objects.exclude(books=book_id),
    }
    return render(request, "02_BookInfo.html", context)

def AddAuthorOnBookInfo(request, book_id):
    add_author_to_this_book = Book.objects.get(id=book_id)
    add_author_to_this_book.authors.add(Author.objects.get(id=request.POST['author_options']))
    return redirect("/books/"+str(book_id))

def AddAnAuthor(request):
    context = {
        'all_authors': Author.objects.all()
    }
    return render(request, "03_AddAnAuthor.html", context)
    
def InputAuthor(request):
    print(request.POST)
    newAuthor = Author.objects.create(first_name=request.POST['first_name_add'], last_name=request.POST['last_name_add'],  notes=request.POST['notes_add'])
    return redirect("/authors")

def AuthorInfo(request, author_id):
    AuthorToShow = Author.objects.get(id=author_id)
    context = {
        'requested_author': AuthorToShow,
        'authors_books': AuthorToShow.books.all(),
        'other_books': Book.objects.exclude(authors=author_id),
    }
    return render(request, "04_AuthorInfo.html", context)

def AddBookOnAuthorInfo(request, author_id):
    add_book_to_this_author = Author.objects.get(id=author_id)
    add_book_to_this_author.books.add(Book.objects.get(id=request.POST['book_options']))
    return redirect("/authors/"+str(author_id))
