from django.urls import path     
from . import views
urlpatterns = [
    path('', views.AddABook, name='book_addition_page'),
    path('bookInput', views.InputBook, name='Intake_Book_Form'),
    path('books/<int:book_id>', views.BookInfo, name='book_info_page'),
    path('authorToBook/<int:book_id>', views.AddAuthorOnBookInfo, name='Author_Add_Book_Info'),
    path('authors', views.AddAnAuthor, name='author_addition_page'),
    path('authorInput', views.InputAuthor, name='Intake_Author_Form'),
    path('authors/<int:author_id>', views.AuthorInfo, name='author_info_page'),
    path('bookToAuthor/<int:author_id>', views.AddBookOnAuthorInfo, name='Book_Add_Author_Info'),
]