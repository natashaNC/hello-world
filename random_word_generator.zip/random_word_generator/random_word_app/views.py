
from django.shortcuts import render, HttpResponse, redirect
from django.utils.crypto import get_random_string 

def index(request):
    request.session.clear()
    return render(request, "index.html")

def randomWord(request):
    context = {
        "random": get_random_string(length=14) 
    }
    if 'count' in request.session:
        print('key exists!')
        request.session['count'] += 1
        print(request.session['count'])
    else:
        request.session['count'] = 1
        print(f"key {request.session['count']} does NOT exist")

    return render(request, 'index.html', context)

def resets(request):
    request.session.clear()
    # print(f"reset {request.session['count']}")
    return redirect("/random_word")


# Create a new project with an app called 'random_word'. This app will render a template with a random 14-character "word" that also display a counter for the number of words generated.
#  The first time you use this app, it should say 'attempt #1'. Each time you generate a new random keyword, it should increment the attempt figure. The purpose of this assignment is to reinforce your use of session. Don't spend too much time on the random word generator portion--it's okay if your random word is not a real word.

# Add functionality so that a request to localhost:8000/random_word/reset resets the counter and redirects back to localhost:8000/random_word.

# For generating a random word, check out this StackOverflow question, which shows us we can:

#     import get_random_string from django.utils.crypto (remember that you can import other libraries/modules in your views.py or any other python files)
#     use get_random_string(length=14) to get a random string of length 14

# urlpatterns = [
#     path('random_word', views.index),
#     path('random_word/reset', views.resets),
# ]
