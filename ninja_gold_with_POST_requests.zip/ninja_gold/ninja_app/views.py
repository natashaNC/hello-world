from django.shortcuts import render, HttpResponse, redirect
import random
from time import localtime, strftime

def index(request):
	if 'score' not in request.session:
		request.session['score'] = 0
	if 'wins_losses' not in request.session:
		request.session['wins_losses'] = []
	request.session['wins_losses'].reverse()
	# request.session['wins_losses'] = request.session['wins_losses'][:4] 
	context = {
		"time_stamp": strftime("%Y/%m/%d %I:%M %p", localtime())}
	return render(request, 'index.html', context)        

def process_gold(request):
	gold_earned = 0
	time = strftime("%Y/%m/%d %I:%M %p", localtime())
	if request.POST['location'] == 'farm_gold':
		gold_earned += random.randint(10,20)
		request.session['score'] += gold_earned
		event = f"Earned {gold_earned} pieces of gold from the farm! {time}"
		request.session['wins_losses'].append(event)
		# request.session.save()
	elif request.POST['location'] == 'cave_gold':
		gold_earned += random.randint(5,10)
		request.session['score'] += gold_earned
		event = f"Earned {gold_earned} pieces of gold from the cave! {time}"
		request.session['wins_losses'].append(event)
		# request.session.save()
	elif request.POST['location'] == 'house_gold':
		gold_earned += random.randint(2, 5)
		request.session['score'] += gold_earned
		event = f"Earned {gold_earned} pieces of gold from the house! {time}"
		request.session['wins_losses'].append(event)
		# request.session.save()
	elif request.POST['location'] == 'casino_gold':
		gold_earned += random.randint(-50,50)
		request.session['score'] += gold_earned
		if gold_earned > 0: 
			if gold_earned == 1:
				event = f"Earned 1 piece of gold from the casino! {time}"
				request.session['wins_losses'].append(event)
				# request.session.save()
			elif gold_earned > 1: 
				event = f"Earned {gold_earned} pieces of gold from the casino! {time}"
				request.session['wins_losses'].append(event)
				# request.session.save()
		elif gold_earned < 0:
			if gold_earned == -1:
				event = f"Entered a casino and lost 1 piece of gold, Ouch... {time}"
				request.session['wins_losses'].append(event)
				# request.session.save()
			elif gold_earned < -1:
				event = f"Entered a casino and lost {abs(gold_earned)} pieces of gold, Ouch... {time}"
				request.session['wins_losses'].append(event)
				# request.session.save()  
		else:
			event = f"Entered a casino and great news! You didn't win anything, you din't lose anything either! {time}"
			request.session['wins_losses'].append(event)
			# request.session.save() 
	return redirect("/")

def scoreReset(request):
	del request.session['score']
	del request.session['wins_losses']
	return redirect("/")