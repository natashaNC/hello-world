from django.apps import AppConfig


class NinjaAppConfig(AppConfig):
    name = 'ninja_app'
