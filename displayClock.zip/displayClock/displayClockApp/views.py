from django.shortcuts import render, HttpResponse, redirect
from time import localtime, strftime

def index(request):
    context = {
        "time": strftime("%I:%M %p", localtime()),
        "date": strftime("%A %B %d, %Y", localtime())}
    
    return render(request, 'index.html', context)

def names(request, name):
    context = {
        "time": strftime("%I:%M %p", localtime()),
        "date": strftime("%A %B %d, %Y", localtime()),
        "first_name": name,

        }
    
    return render(request, 'index.html', context)

def phrases(request, name, phrase):
    context = {
        "time": strftime("%I:%M %p", localtime()),
        "date": strftime("%A %B %d, %Y", localtime()),
        "first_name": name,
        "clause": phrase
        }
    
    return render(request, 'index.html', context)