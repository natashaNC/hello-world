from django.apps import AppConfig


class DisplayclockappConfig(AppConfig):
    name = 'displayClockApp'
